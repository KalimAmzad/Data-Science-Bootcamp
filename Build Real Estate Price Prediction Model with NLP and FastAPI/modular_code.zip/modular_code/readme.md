### Install all the dependencies

pip install -r requirements.txt

### Run the engine.py file to execute the code

### Enter 1 to train the model

### Enter 2 to run the FastAPI app.py file to run the web application
